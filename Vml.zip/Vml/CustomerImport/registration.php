<?php
/**
 *  @Module         : Customer Import
 *  @Package        : Vml_CustomerImport
 *  @Description    : Customer Import
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Vml_CustomerImport',
    __DIR__
);